#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Менеджер правил Windows Firewall (аналог iptables для Windows 10/11)

.DESCRIPTION
    Интерактивный скрипт для создания, просмотра, включения/отключения и удаления
    правил брандмауэра. Поддерживает выбор портов, направления (входящие/исходящие),
    действия (разрешить/заблокировать) и пользовательские названия.

.NOTES
    Запускайте PowerShell от имени администратора.
    Пример: powershell -ExecutionPolicy Bypass -File .\FirewallManager.ps1
#>

$Script:RuleGroupName = "FirewallManager_Custom"

function Write-Header {
    param([string]$Title)
    Write-Host ""
    Write-Host ("=" * 60) -ForegroundColor Cyan
    Write-Host "  $Title" -ForegroundColor Cyan
    Write-Host ("=" * 60) -ForegroundColor Cyan
}

function Test-AdminRights {
    $current = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not $current.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Host "ОШИБКА: Скрипт требует прав администратора." -ForegroundColor Red
        Write-Host "Запустите PowerShell от имени администратора и повторите." -ForegroundColor Yellow
        exit 1
    }
}

function Read-Choice {
    param(
        [string]$Prompt,
        [string[]]$Options,
        [int]$Default = 0
    )
    for ($i = 0; $i -lt $Options.Count; $i++) {
        $marker = if ($i -eq $Default) { "*" } else { " " }
        Write-Host "  [$marker] $($i + 1). $($Options[$i])"
    }
    $input = Read-Host "$Prompt [1-$($Options.Count), Enter = $($Default + 1)]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $Default }
    $num = 0
    if ([int]::TryParse($input, [ref]$num) -and $num -ge 1 -and $num -le $Options.Count) {
        return $num - 1
    }
    Write-Host "Неверный выбор, используется значение по умолчанию." -ForegroundColor Yellow
    return $Default
}

function Read-PortList {
    param([string]$Prompt = "Введите порты")
    Write-Host ""
    Write-Host "  Форматы: 80 | 80,443,8080 | 1000-1010 | 80,1000-1010,443" -ForegroundColor DarkGray
    $raw = Read-Host $Prompt
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }

    $ports = [System.Collections.Generic.HashSet[int]]::new()
    $parts = $raw -split '[,\s;]+' | Where-Object { $_ -match '\S' }

    foreach ($part in $parts) {
        if ($part -match '^(\d+)-(\d+)$') {
            $start = [int]$Matches[1]
            $end   = [int]$Matches[2]
            if ($start -gt $end) { $t = $start; $start = $end; $end = $t }
            if ($start -lt 1 -or $end -gt 65535) {
                throw "Диапазон портов вне 1-65535: $part"
            }
            for ($p = $start; $p -le $end; $p++) { [void]$ports.Add($p) }
        }
        elseif ($part -match '^\d+$') {
            $p = [int]$part
            if ($p -lt 1 -or $p -gt 65535) { throw "Порт вне диапазона 1-65535: $p" }
            [void]$ports.Add($p)
        }
        else {
            throw "Неверный формат порта: $part"
        }
    }

    return ($ports | Sort-Object)
}

function Get-CustomRules {
    Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayGroup -eq $Script:RuleGroupName -or $_.Group -eq $Script:RuleGroupName } |
        Sort-Object DisplayName
}

function Format-RuleInfo {
    param($Rule)

    $portFilter = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $Rule -ErrorAction SilentlyContinue
    $protocol   = if ($portFilter.Protocol) { $portFilter.Protocol } else { "Any" }
    $ports      = switch -Regex ($portFilter.LocalPort) {
        'Any' { "любые" }
        default { $portFilter.LocalPort }
    }

    [PSCustomObject]@{
        Name      = $Rule.DisplayName
        Direction = switch ($Rule.Direction) { 'Inbound' { 'Входящие' }; 'Outbound' { 'Исходящие' }; default { $Rule.Direction } }
        Action    = switch ($Rule.Action) { 'Allow' { 'Разрешить' }; 'Block' { 'Заблокировать' }; default { $Rule.Action } }
        Protocol  = $protocol
        Ports     = $ports
        Enabled   = $Rule.Enabled
        Profile   = ($Rule.Profile -join ', ')
    }
}

function Show-Rules {
    Write-Header "Список правил ($Script:RuleGroupName)"
    $rules = Get-CustomRules

    if (-not $rules) {
        Write-Host "  Правила не найдены." -ForegroundColor Yellow
        return
    }

    $i = 1
    foreach ($rule in $rules) {
        $info = Format-RuleInfo $rule
        $status = if ($info.Enabled) { "ВКЛ" } else { "ВЫКЛ" }
        $color  = if ($info.Enabled) { "Green" } else { "DarkGray" }
        Write-Host ""
        Write-Host "  [$i] $($info.Name)" -ForegroundColor $color
        Write-Host "      Направление : $($info.Direction)"
        Write-Host "      Действие    : $($info.Action)"
        Write-Host "      Протокол    : $($info.Protocol)"
        Write-Host "      Порты       : $($info.Ports)"
        Write-Host "      Профили     : $($info.Profile)"
        Write-Host "      Статус      : $status"
        $i++
    }
}

function New-CustomRule {
    Write-Header "Создание нового правила"

    $name = Read-Host "Название правила"
    if ([string]::IsNullOrWhiteSpace($name)) {
        Write-Host "Название обязательно." -ForegroundColor Red
        return
    }

    $existing = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "Правило с таким названием уже существует." -ForegroundColor Red
        return
    }

    $dirIdx = Read-Choice -Prompt "Выберите направление" -Options @(
        "Входящие (Inbound) — трафик к вашему ПК",
        "Исходящие (Outbound) — трафик с вашего ПК"
    )
    $direction = @('Inbound', 'Outbound')[$dirIdx]

    $actIdx = Read-Choice -Prompt "Выберите действие" -Options @(
        "Разрешить (Allow)",
        "Заблокировать (Block)"
    )
    $action = @('Allow', 'Block')[$actIdx]

    $protoIdx = Read-Choice -Prompt "Выберите протокол" -Options @(
        "TCP",
        "UDP",
        "TCP и UDP (два отдельных правила)",
        "Любой (Any) — без фильтра по порту"
    )

    $profiles = @('Domain', 'Private', 'Public')
    Write-Host ""
    Write-Host "Профили сети (через запятую: 1=Domain, 2=Private, 3=Public, Enter=все):" -ForegroundColor DarkGray
    $profInput = Read-Host "Профили"
    if (-not [string]::IsNullOrWhiteSpace($profInput)) {
        $selected = @()
        foreach ($p in ($profInput -split '[,\s]+')) {
            switch ($p.Trim()) {
                '1' { $selected += 'Domain' }
                '2' { $selected += 'Private' }
                '3' { $selected += 'Public' }
                'Domain'  { $selected += 'Domain' }
                'Private' { $selected += 'Private' }
                'Public'  { $selected += 'Public' }
            }
        }
        if ($selected.Count -gt 0) { $profiles = $selected | Select-Object -Unique }
    }

    $portList = @()
    if ($protoIdx -ne 3) {
        try {
            $portList = Read-PortList -Prompt "Порты (Enter = все порты)"
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
            return
        }
    }

    $portParam = @{}
    if ($portList.Count -gt 0) {
        $portParam.LocalPort = ($portList -join ',')
    }

    $protocols = switch ($protoIdx) {
        0 { @('TCP') }
        1 { @('UDP') }
        2 { @('TCP', 'UDP') }
        3 { @('Any') }
    }

    $created = @()
    foreach ($proto in $protocols) {
        $ruleName = if ($protocols.Count -gt 1) { "$name ($proto)" } else { $name }

        $params = @{
            DisplayName = $ruleName
            Group       = $Script:RuleGroupName
            Direction   = $direction
            Action      = $action
            Protocol    = $proto
            Profile     = $profiles
            Enabled     = 'True'
        }
        if ($portParam.Count -gt 0 -and $proto -ne 'Any') {
            $params.LocalPort = $portParam.LocalPort
        }

        try {
            New-NetFirewallRule @params | Out-Null
            $created += $ruleName
        }
        catch {
            Write-Host "Ошибка создания '$ruleName': $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    if ($created.Count -gt 0) {
        Write-Host ""
        Write-Host "Создано правил: $($created -join ', ')" -ForegroundColor Green
    }
}

function Set-RuleState {
    param([bool]$Enable)

    Show-Rules
    $rules = @(Get-CustomRules)
    if ($rules.Count -eq 0) { return }

    $input = Read-Host "Номер правила (0 = отмена)"
    if ($input -eq '0' -or [string]::IsNullOrWhiteSpace($input)) { return }

    $num = 0
    if (-not [int]::TryParse($input, [ref]$num) -or $num -lt 1 -or $num -gt $rules.Count) {
        Write-Host "Неверный номер." -ForegroundColor Red
        return
    }

    $rule = $rules[$num - 1]
    Set-NetFirewallRule -Name $rule.Name -Enabled $(if ($Enable) { 'True' } else { 'False' })
    $verb = if ($Enable) { "включено" } else { "отключено" }
    Write-Host "Правило '$($rule.DisplayName)' $verb." -ForegroundColor Green
}

function Remove-CustomRule {
    Show-Rules
    $rules = @(Get-CustomRules)
    if ($rules.Count -eq 0) { return }

    Write-Host ""
    Write-Host "  [0] Отмена" -ForegroundColor DarkGray
    Write-Host "  [A] Удалить все правила группы" -ForegroundColor DarkGray
    $input = Read-Host "Номер правила для удаления"

    if ($input -eq '0' -or [string]::IsNullOrWhiteSpace($input)) { return }

    if ($input -match '^[Aa]$') {
        $confirm = Read-Host "Удалить ВСЕ $($rules.Count) правил? (yes/no)"
        if ($confirm -eq 'yes') {
            $rules | Remove-NetFirewallRule
            Write-Host "Все правила удалены." -ForegroundColor Green
        }
        return
    }

    $num = 0
    if (-not [int]::TryParse($input, [ref]$num) -or $num -lt 1 -or $num -gt $rules.Count) {
        Write-Host "Неверный номер." -ForegroundColor Red
        return
    }

    $rule = $rules[$num - 1]
    $confirm = Read-Host "Удалить '$($rule.DisplayName)'? (yes/no)"
    if ($confirm -eq 'yes') {
        Remove-NetFirewallRule -Name $rule.Name
        Write-Host "Правило удалено." -ForegroundColor Green
    }
}

function Export-RulesBackup {
    $rules = Get-CustomRules
    if (-not $rules) {
        Write-Host "Нет правил для экспорта." -ForegroundColor Yellow
        return
    }

    $backup = foreach ($rule in $rules) {
        $portFilter = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $rule
        [PSCustomObject]@{
            DisplayName = $rule.DisplayName
            Direction   = $rule.Direction
            Action      = $rule.Action
            Protocol    = $portFilter.Protocol
            LocalPort   = $portFilter.LocalPort
            Profile     = $rule.Profile
            Enabled     = $rule.Enabled
            Group       = $Script:RuleGroupName
        }
    }

    $path = Join-Path $env:USERPROFILE "FirewallManager_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $backup | ConvertTo-Json -Depth 3 | Set-Content -Path $path -Encoding UTF8
    Write-Host "Резервная копия сохранена: $path" -ForegroundColor Green
}

function Import-RulesBackup {
    $path = Read-Host "Путь к JSON-файлу резервной копии"
    if (-not (Test-Path $path)) {
        Write-Host "Файл не найден." -ForegroundColor Red
        return
    }

    try {
        $items = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($items -isnot [Array]) { $items = @($items) }

        $count = 0
        foreach ($item in $items) {
            if (Get-NetFirewallRule -DisplayName $item.DisplayName -ErrorAction SilentlyContinue) {
                Write-Host "Пропуск (уже есть): $($item.DisplayName)" -ForegroundColor Yellow
                continue
            }

            $params = @{
                DisplayName = $item.DisplayName
                Group       = $Script:RuleGroupName
                Direction   = $item.Direction
                Action      = $item.Action
                Protocol    = $item.Protocol
                Profile     = $item.Profile
                Enabled     = $item.Enabled
            }
            if ($item.LocalPort -and $item.LocalPort -ne 'Any') {
                $params.LocalPort = $item.LocalPort
            }
            New-NetFirewallRule @params | Out-Null
            $count++
        }
        Write-Host "Импортировано правил: $count" -ForegroundColor Green
    }
    catch {
        Write-Host "Ошибка импорта: $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Show-MainMenu {
    Write-Header "Менеджер Windows Firewall"
    Write-Host "  Группа правил: $Script:RuleGroupName" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  1. Создать правило"
    Write-Host "  2. Список правил"
    Write-Host "  3. Включить правило"
    Write-Host "  4. Отключить правило"
    Write-Host "  5. Удалить правило"
    Write-Host "  6. Экспорт резервной копии"
    Write-Host "  7. Импорт резервной копии"
    Write-Host "  0. Выход"
    Write-Host ""
}

Test-AdminRights

Write-Host ""
Write-Host "  Windows Firewall Manager" -ForegroundColor White
Write-Host "  (аналог iptables для Windows)" -ForegroundColor DarkGray

do {
    Show-MainMenu
    $choice = Read-Host "Выберите действие"
    switch ($choice) {
        '1' { New-CustomRule }
        '2' { Show-Rules }
        '3' { Set-RuleState -Enable $true }
        '4' { Set-RuleState -Enable $false }
        '5' { Remove-CustomRule }
        '6' { Export-RulesBackup }
        '7' { Import-RulesBackup }
        '0' { Write-Host "Выход." -ForegroundColor Cyan; break }
        default { Write-Host "Неизвестный пункт меню." -ForegroundColor Yellow }
    }
    if ($choice -ne '0') {
        Read-Host "`nНажмите Enter для продолжения"
    }
} while ($choice -ne '0')
